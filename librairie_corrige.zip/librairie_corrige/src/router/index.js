import Vue from 'vue'
import Router from 'vue-router'
import Rayon from '@/components/Rayon'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Rayon',
      component: Rayon
    }
  ]
})
