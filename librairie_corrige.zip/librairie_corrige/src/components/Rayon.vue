<script>

import Livre from './Livre.vue'

export default {
  name: 'Rayon',
  components : {
    Livre
  },

  data: function () {
    return {
      nbLivresLikes:0,
      livres : [
        { titre: "Le Petit Prince", annee: "1943", nbPages: 300, auteur: 'Antoine de Saint-Exupéry', like: true },
        { titre: "Les fleurs du mal", annee: "1857", nbPages: 635, auteur: 'Charles baudelaire', like: false },
        { titre: "Le rouge et le noir", annee: "1831", nbPages: 380, auteur: 'Stendhal', like: true }
      ]
    }
  },
beforeCreate: {
// init nb likes
},
  methods: {
    addLike: function() {
      this.nbLivresLikes++;
    },
    deleteLike: function() {
      this.nbLivresLikes--;
    }
  },

  filters : {
    
  }
}
</script>
<template>
<div>
    Détail du rayon :

    Nombre de livres likes = {{nbLivresLikes}}

    <br><br>



   <Livre v-for="(item, index) in livres" v-bind:titre="item.titre" v-bind:auteur="item.auteur" v-bind:nbPages="item.nbPages" v-bind:annee="item.annee" v-bind:index="index" v-bind:key="item.id" @like-event="addLike" @dislike-event="deleteLike" ></Livre>



</div>


</div>

</template>