<script>
export default {
    name: 'Livre',
    props: ['titre', 'auteur', 'nbPages', 'annee','like'],
    
    data: function() {
        return {
            liked:this.like
        }
    },
    methods: {
        emitLikeEvent() {
            this.liked=true;
            this.$emit('like-event', { message: 'like' })
        },
        emitDislikeEvent() {
            this.liked=false;
            this.$emit('dislike-event', { message: 'dislike' })
        }
    }
}
</script>
<template>
<div>{{titre}} - {{auteur}} - {{nbPages}} - {{annee}}<img v-if="liked" width = "1%" src="../assets/images/coeur.png"> <button v-if="!liked" @click="emitLikeEvent">liker!</button><button v-if="liked" @click="emitDislikeEvent">disliker!</button></div>
</template>