<script>
import MovieAffiche from './MovieAffiche.vue'
export default {
    name: 'Movie',
    props: ['movie'],
    components: {
        MovieAffiche
    },
    data: function() {
      return {
          colorTitre:""
      }
    },
    filters: {
        'capitalize': function (value) {
            if (!value) return ''
                value = value.toString()
            return value.charAt(0).toUpperCase() + value.slice(1,value.length-1) + value.charAt(value.length-1).toUpperCase()
        }
    },
    methods: {
        mouseOverTitre: function() {
            this.colorTitre = "green"
        },
        mouseOutTitre: function() {
            this.colorTitre = "black"
        }
    }
}
</script>
<template>
<div>
<br>
<div><h1 @mouseover="mouseOverTitre" @mouseout="mouseOutTitre" :style="{ color : this.colorTitre }">{{this.movie.title | capitalize}} ({{this.movie.language}})</h1></div>
<div><h2>{{this.movie.actors}}</h2></div>
<div><h3>{{this.movie.year}}</h3></div>
<div><h4><router-link :to="{name : 'MovieAffiche', params: {movieId: this.movie.id}}">Aperçu</router-link></h4></div>
<br>
</div>
</template>