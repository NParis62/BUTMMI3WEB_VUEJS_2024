<template>
  <div id="page404">
  <NavLink/>
    Page 404
  </div>
</template>

<script>

import NavLink from './NavLink.vue'

export default {
  name: 'Page404',
  components: {
    NavLink
  }
}
</script>

<style>
</style>