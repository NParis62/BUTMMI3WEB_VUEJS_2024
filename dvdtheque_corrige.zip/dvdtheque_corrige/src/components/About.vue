<template>
  <div id="about">
  <NavLink/>
    This is About vue
  </div>
</template>

<script>

import NavLink from './NavLink.vue'

export default {
  name: 'About',
  components: {
    NavLink
  }
}
</script>

<style>
</style>