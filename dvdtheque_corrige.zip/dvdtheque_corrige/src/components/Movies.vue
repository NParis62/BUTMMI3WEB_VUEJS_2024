<template>
  <div id="movies">
 <NavLink/>



 <br>
    Titre <input v-model="searchTitle" type="text">
    Année <input v-model="searchYear" type="text">
    Langue <input v-model="searchLanguage" type="text">
    Acteurs <input v-model="searchActors" type="text">

<br>
    
    <h1 :style="{ color : 'red' }">Liste des films</h1>


    <Movie v-for="(movie, index) in filterMovies" v-bind:movie="movie" v-bind:index="index" v-bind:key="movie.id"></Movie>
  </div>
</template>

<script>

import Movie from './Movie.vue'
import NavLink from './NavLink.vue'

export default {
  name: 'Movies',
  data: function() {
      return {
          movies: require('../assets/data/films.json')["movies"],
          searchTitle:'',
          searchYear:'',
          searchLanguage:'',
          searchActors:'',
          jsonMovies: require('../assets/data/films.json')
      }
  },
  components: {
    Movie, NavLink
  },
  computed: {
    filterMovies: function(){
      return this.filterMovieByTitle(this.filterMovieByYear(this.filterMovieByLanguage(this.filterMovieByActors(this.movies))))
    }
  },
  methods: {
    filterMovieByTitle: function(movies){
      if(this.searchTitle)
        return movies.filter(movie => movie.title.toLowerCase().includes(this.searchTitle.toLowerCase()))
      else return movies
    },

    filterMovieByLanguage: function(movies) {
      if(this.searchLanguage)
        return movies.filter(movie => movie.language.toLowerCase().includes(this.searchLanguage.toLowerCase()))
      else return movies
    },

    filterMovieByYear: function(movies){
      if(this.searchYear)
        return movies.filter(movie => (movie.year == this.searchYear) ? movie : '')
      else return movies
    },

    filterMovieByActors: function(movies){
      if(this.searchActors)
        return movies.filter(movie => movie.actors.join().toLowerCase().includes(this.searchActors.toLowerCase()))
      else return movies
    }
  },

}
</script>

 <style type="text/css">
            span.red {
               color: red;
               font-weight: bold;
           }
           </style>