<template>
  <div id="navlink">
    <router-link class="nav-link" to="/home">Home</router-link>
    <router-link class="nav-link" to="/movies">Movies</router-link>
    <router-link class="nav-link" to="/about">About</router-link>
  </div>
</template>

<script>
export default {
  name: 'NavLink'
}
</script>

<style>
</style>