<template>
  <div id="home">
  <NavLink/>
    This is Home vue
  </div>
</template>

<script>

import NavLink from './NavLink.vue'

export default {
  name: 'Home',
  components: {
    NavLink
  }
}
</script>

<style>
</style>