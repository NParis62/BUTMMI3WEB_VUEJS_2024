<template>
  <div id="movieAffiche">
  <NavLink/>
    <img :src="imageMovie" width="300px"/>
  </div>
</template>

<script>

import NavLink from './NavLink.vue'

export default {
  name: 'MovieAffiche',
  components: {
    NavLink
  },
  data: function() {
    return {
      afficheMovies:[],
      imageMovie:require("../assets/images/"+this.$route.params.movieId+".jpeg")
    }
  }
}
</script>

<style>
</style>