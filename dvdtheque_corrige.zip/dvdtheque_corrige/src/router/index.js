import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import Movies from '@/components/Movies'
import About from '@/components/About'
import MovieAffiche from '@/components/MovieAffiche'
import Page404 from '@/components/Page404'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'root',
      component: Home
    },
    {
      path: '/home',
      name: 'home',
      component: Home
    },
    {
      path: '/movies',
      name: 'movies',
      component: Movies
    },
    {
      path: '/about',
      name: 'about',
      component: About
    },
    {
      path: '/movieAffiche/:movieId',
      name: 'MovieAffiche',
      component: MovieAffiche
    },
    {
      path: '/*',
      name: 'Page404',
      component: Page404
    }
  ]
})
